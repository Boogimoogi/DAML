import pandas as pd
import numpy as np

data = pd.read_csv('HousingData.csv')
dt = data

dt.drop_duplicates(inplace=True)
dt.dropna(inplace=True)

# Convert the data to the correct type
dt["Miles (dist. between school and house)"] = dt["Miles (dist. between school and house)"].astype(int)
dt["Rent Price per Month"] = dt["Rent Price per Month"].astype(int)
dt["Sell Price"] = dt["Sell Price"].astype(int)

## in city center,>=2 rooms,,maximum +25% of renting price,miles ot school as near as possible
# Filter out the house locate in city center
dt_rent = dt.loc[(dt['Location'] == "City Center")]
# Filter out the house with 2 rooms
dt_rent = dt_rent.drop(dt_rent[dt_rent['No. of Rooms'] < 2].index)
# Get details of the house of the rent price
# print(dt_in_city['Rent Price per Month'].describe()) #75% = 17053 50% = 13446 mean = 13387
dt_rent = dt_rent.drop(dt_rent[dt_rent['Rent Price per Month'] > 17053].index)
# Get details of the house of the miles to school
dt_rent.sort_values(by=['Miles (dist. between school and house)'], inplace=True, ascending=True)
# print (dt_rent.head(3))

##buying a house
dt_buy = dt.loc[(dt['Location'] == "City Center")]
dt_buy = dt_buy.drop(dt_buy[dt_buy["No. of Rooms"] < 2].index)
dt_buy = dt_buy.sort_values(by=["No. of Rooms"], ascending = False)
# print(dt_buy["Sell Price"].describe())
dt_buy = dt_buy.drop(dt_buy[dt_buy["Sell Price"] > 5.00e+07].index)
dt_buy.sort_values(by=['Miles (dist. between school and house)'], inplace=True, ascending=True)
# print (dt_buy.head(2))

##dig into the high price house
dt_buy_high = dt.sort_values(by = ["Sell Price"], ascending = False).head(30)
dt_rent_high = dt.sort_values(by = ["Rent Price per Month"], ascending = False).head(30)
# print(dt_buy_high)
print(dt_rent_high)
print (dt["Area"].describe())
print (dt["Sell Price"].describe())
# print(dt["Sell Price"].describe()) 

#dig into the low price house
# dt_rent_high = dt.sort_values(by = ["Rent Price per Month"], ascending = False).head(30)
# dt_rent_low = dt.sort_values(by = ["Rent Price per Month"], ascending = True).head(30)
# print(dt_rent_high)
# print(dt_rent_low)




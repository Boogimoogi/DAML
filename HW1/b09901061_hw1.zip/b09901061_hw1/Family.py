import pandas as pd
import numpy as np
import re

data = pd.read_csv('FamilyData.csv')
dt = data

duplicates = dt.duplicated()
print("Duplicates:")
print(dt[duplicates])

# Check for empty values
empty_values = dt.isnull().any(axis=1)
print("\nEmpty values:")
print(dt[empty_values])



dt = data.drop_duplicates()
# print(dt.unique())
dt = data.dropna()
# print(dt.describe())

#preprocess
##family num
def family_num(x):
    num = re.findall(r'\d+', x)
    return int(num[0])

def join_member(x):
    return " ".join(x)



dt["Family_num"] = dt["Family"].apply(family_num)
dt["Adult_num"] = dt["Member"].str.contains("Adult")
dt["Child_num"] = dt["Member"].str.contains("Child")
# print(dt["Adult_num"])

aggregation_function = {"Spend":"sum","Income":"sum","Family_num":"first","Adult_num":"sum","Child_num":"sum","Member":join_member}
dt = dt.groupby(dt["Family"]).aggregate(aggregation_function)
dt["Family_num"] = dt["Family_num"].astype(int)
dt["Family_num"] = dt["Family_num"].astype(int)
dt = dt.sort_values(by = ["Family_num"], ascending = True)

# print(dt["Income"].max())
# print ("Highest annual income: ")
# print(dt.loc[dt["Income"].idxmax()])
# print ("Lowest annual income: ")
# print(dt.loc[dt["Income"].idxmin()])


# single parent
dt_single = dt.loc[(dt['Adult_num'] == 1) & (dt['Child_num'] > 0)]
# print (dt_single)
print (dt_single.count())

# childless
dt_childless = dt.loc[((dt['Child_num'] == 0) & (dt['Adult_num'] < 3)) ]
# print (dt_childless)
print (dt_childless.count())


# print(dt)



#boasting
